import { createUIMessageStream, createUIMessageStreamResponse, type UIMessage } from "ai"
import Groq from "groq-sdk"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY })

const SYSTEM_PROMPT =
  "You are Gistt, a fast and friendly AI assistant powered by Groq. " +
  "Give clear, well-structured answers. Get to the gist quickly, but be thorough when it matters. " +
  "Use Markdown for formatting when helpful."

function toGroqMessages(messages: UIMessage[]) {
  return messages.map((message) => ({
    role: message.role as "user" | "assistant" | "system",
    content: message.parts
      .filter((part) => part.type === "text")
      .map((part) => (part as { text: string }).text)
      .join(""),
  }))
}

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const stream = createUIMessageStream({
    execute: async ({ writer }) => {
      const completion = await groq.chat.completions.create({
        model: "openai/gpt-oss-20b",
        stream: true,
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...toGroqMessages(messages)],
      })

      const textId = crypto.randomUUID()
      writer.write({ type: "text-start", id: textId })

      for await (const chunk of completion) {
        const delta = chunk.choices[0]?.delta?.content
        if (delta) {
          writer.write({ type: "text-delta", id: textId, delta })
        }
      }

      writer.write({ type: "text-end", id: textId })
    },
    onError: (error) => {
      console.error("[v0] Groq chat error:", error)
      return "Something went wrong while talking to Groq."
    },
  })

  return createUIMessageStreamResponse({ stream })
}
