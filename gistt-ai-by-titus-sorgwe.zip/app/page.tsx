import { GisttHeader } from "@/components/gistt-header"
import { GisttFooter } from "@/components/gistt-footer"
import { ChatPanel } from "@/components/chat-panel"

export default function Page() {
  return (
    <div className="flex h-dvh flex-col bg-background text-foreground">
      <GisttHeader />
      <main className="flex min-h-0 flex-1 flex-col">
        <ChatPanel />
      </main>
      <GisttFooter />
    </div>
  )
}
