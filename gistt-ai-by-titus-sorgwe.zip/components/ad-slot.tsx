import { cn } from "@/lib/utils"

interface AdSlotProps {
  label?: string
  className?: string
  height?: string
}

/**
 * Placeholder advertising slot. Swap the inner content for a real ad network
 * embed (e.g. an AdSense <ins> tag) when wiring up monetization.
 */
export function AdSlot({ label = "Advertisement", className, height = "h-[90px]" }: AdSlotProps) {
  return (
    <div
      role="complementary"
      aria-label={label}
      className={cn(
        "flex w-full items-center justify-center overflow-hidden rounded-lg border border-dashed border-border bg-muted/30 text-muted-foreground",
        height,
        className,
      )}
    >
      <div className="flex flex-col items-center gap-1">
        <span className="text-[10px] font-medium uppercase tracking-[0.2em]">{label}</span>
        <span className="text-xs text-muted-foreground/60">Your ad could be here</span>
      </div>
    </div>
  )
}
