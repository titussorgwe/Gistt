import { AdSlot } from "@/components/ad-slot"

export function GisttFooter() {
  return (
    <footer className="sticky bottom-0 z-20 border-t border-border bg-background/80 backdrop-blur">
      <div className="mx-auto max-w-3xl px-4 pt-3">
        <AdSlot label="Advertisement" height="h-[60px] sm:h-[90px]" />
      </div>
      <div className="mx-auto max-w-3xl px-4 py-2">
        <p className="text-center text-[11px] text-muted-foreground/70">
          Gistt can make mistakes. Consider verifying important information.
        </p>
      </div>
    </footer>
  )
}
