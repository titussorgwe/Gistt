import { Sparkles } from "lucide-react"
import { AdSlot } from "@/components/ad-slot"

export function GisttHeader() {
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-3xl items-center justify-between gap-4 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Sparkles className="size-4" aria-hidden="true" />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-semibold tracking-tight">Gistt</p>
            <p className="text-[11px] text-muted-foreground">Powered by Groq</p>
          </div>
        </div>
        <span className="rounded-full border border-border bg-muted/40 px-2.5 py-1 text-[11px] text-muted-foreground">
          Groq
        </span>
      </div>
      <div className="mx-auto max-w-3xl px-4 pb-3">
        <AdSlot label="Sponsored" height="h-[60px] sm:h-[90px]" />
      </div>
    </header>
  )
}
